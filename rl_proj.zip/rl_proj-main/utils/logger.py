import csv, os, matplotlib.pyplot as plt

class Logger:
    def __init__(self, out_dir="results", fname="train_log.csv"):
        os.makedirs(out_dir, exist_ok=True)
        self.path = os.path.join(out_dir, fname)
        self.rows = []

    def record(self, metrics: dict):
        self.rows.append(metrics)
        with open(self.path, "w", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=self.rows[0].keys())
            writer.writeheader()
            writer.writerows(self.rows)

    def plot(self, y_key="eval_mean"):
        if not self.rows: return
        xs = [r["step"] for r in self.rows if y_key in r]
        ys = [r[y_key] for r in self.rows if y_key in r]
        plt.plot(xs, ys)
        plt.xlabel("Step")
        plt.ylabel(y_key)
        plt.title("Training curve")
        plt.grid(True)
        plt.savefig(self.path.replace(".csv", f"_{y_key}.png"))
        plt.close()
