# algorithms/mpo.py
"""
MPO: Maximum a Posteriori Policy Optimization (approximate)
We implement an E-step (soft targets) and approximate M-step via penalized loss:
    loss = - sum_i q_i * logpi(i) + lambda_kl * q-weighted (logpi - logpi_ref)
This is the common practical approximation when QP solver is not used.
"""

from typing import Optional
import numpy as np
import torch


class MPO:
    def __init__(self, eta: float = 1.0, lambda_kl: float = 0.1, K: int = 8, eval_fn=None, device: Optional[str] = None):
        self.eta = eta
        self.lambda_kl = lambda_kl
        self.K = K
        self.eval_fn = eval_fn
        self.device = device

    def _compute_q(self, returns):
        arr = np.array(returns, dtype=float)
        logits = arr / (self.eta + 1e-12)
        logits = logits - logits.max()
        ex = np.exp(logits)
        q = ex / (ex.sum() + 1e-12)
        return q

    def step(self, trainer):
        device = trainer.device if self.device is None else self.device

        if hasattr(trainer, "sample_candidates"):
            ctx = trainer.env.reset()
            acts = trainer.sample_candidates(ctx, K=self.K)
            scores = trainer.score_actions(ctx, acts)  # proxy returns
            q = self._compute_q(scores)

            obs = torch.tensor(ctx, dtype=torch.float32, device=device).unsqueeze(0)
            obs_batch = obs.repeat(self.K, 1)
            acts_t = torch.tensor(np.array(acts), dtype=torch.float32, device=device)
            
            obs_batch = obs_batch.to(device)
            acts_t = acts_t.to(device)

            logp = trainer.policy.log_prob(obs_batch, acts_t).squeeze(-1)
            if getattr(trainer, "ref_policy", None) is not None:
                with torch.no_grad():
                    logp_ref = trainer.ref_policy.log_prob(obs_batch, acts_t).squeeze(-1)
            else:
                logp_ref = torch.zeros_like(logp).detach()

            q_t = torch.tensor(q, dtype=torch.float32, device=device)
            expected_logp = (q_t * logp).sum()
            div = (q_t * (logp - logp_ref)).sum()
            loss = - expected_logp + self.lambda_kl * div

            trainer.optimizer.zero_grad()
            loss.backward()
            trainer.optimizer.step()

            metrics = {"loss": float(loss.item()), "expected_logp": float(expected_logp.item()), "div": float(div.item())}
            if self.eval_fn:
                metrics.update(self.eval_fn())
            return metrics

        else:
            trajs = [trainer.rollout() for _ in range(self.K)]
            returns = [trainer.trajectory_score(t) for t in trajs]
            q = self._compute_q(returns)

            loss = None
            expected_logp = 0.0
            div = 0.0
            for i, traj in enumerate(trajs):
                lp = trainer.logprob_trajectory(traj)
                if not isinstance(lp, torch.Tensor):
                    lp = torch.tensor(float(lp), dtype=torch.float32, device=device)
                if getattr(trainer, "_ref_logprob_trajectory", None):
                    ref_lp = trainer._ref_logprob_trajectory(traj)
                    if not isinstance(ref_lp, torch.Tensor):
                        ref_lp = torch.tensor(float(ref_lp), dtype=torch.float32, device=device)
                else:
                    ref_lp = torch.tensor(0.0, device=device)
                q_i = float(q[i])
                this = - q_i * lp + self.lambda_kl * q_i * (lp - ref_lp)
                loss = this if loss is None else loss + this
                expected_logp += q_i * lp.item()
                div += q_i * (lp - ref_lp).item()

            trainer.optimizer.zero_grad()
            loss.backward()
            trainer.optimizer.step()

            metrics = {"loss": float(loss.item()), "expected_logp": float(expected_logp), "div": float(div)}
            if self.eval_fn:
                metrics.update(self.eval_fn())
            return metrics

    def train(self, trainer, num_steps=1000, eval_interval=100):
        logs = []
        for s in range(1, num_steps + 1):
            m = self.step(trainer)
            if s % eval_interval == 0 or s == 1:
                print(f"[MPO] step {s} loss {m['loss']:.4f}")
                logs.append({"step": s, **m})
        return logs
