# algorithms/ipo.py
"""
IPO (Implicit Preference Optimization) simplified variant.
We implement a straightforward pairwise logistic loss on log-prob differences,
interpreting returns as proxy preferences when needed.
"""

from typing import Optional
import numpy as np
import torch
import torch.nn.functional as F


class IPO:
    def __init__(self, beta: float = 1.0, eval_fn=None, device: Optional[str] = None):
        self.beta = beta
        self.eval_fn = eval_fn
        self.device = device

    def step(self, trainer):
        device = trainer.device if self.device is None else self.device

        if hasattr(trainer, "sample_candidates"):
            ctx = trainer.env.reset()
            acts = trainer.sample_candidates(ctx, K=2)
            scores = trainer.score_actions(ctx, acts)
            winner = 0 if scores[0] >= scores[1] else 1

            obs = torch.tensor(ctx, dtype=torch.float32, device=device).unsqueeze(0)
            acts_t = torch.tensor(np.array(acts), dtype=torch.float32, device=device)
            
            obs_batch = obs_batch.to(device)
            acts_t = acts_t.to(device)

            
            logp = trainer.policy.log_prob(obs.repeat(2,1), acts_t).squeeze(-1)
            with torch.no_grad():
                logp_ref = trainer.ref_policy.log_prob(obs.repeat(2,1), acts_t).squeeze(-1)

            w = winner
            l = 1 - w
            z = self.beta * ((logp[w] - logp[l]) - (logp_ref[w] - logp_ref[l]))
            loss = F.binary_cross_entropy_with_logits(z, torch.ones_like(z))

            trainer.optimizer.zero_grad()
            loss.backward()
            trainer.optimizer.step()

            metrics = {"loss": float(loss.item()), "winner": int(winner)}
            if self.eval_fn:
                metrics.update(self.eval_fn())
            return metrics

        else:
            trajA = trainer.rollout()
            trajB = trainer.rollout()
            rA = trainer.trajectory_score(trajA)
            rB = trainer.trajectory_score(trajB)
            winner = 1.0 if rA >= rB else 0.0

            logpA = trainer.logprob_trajectory(trajA)
            logpB = trainer.logprob_trajectory(trajB)
            if not isinstance(logpA, torch.Tensor):
                logpA = torch.tensor(float(logpA), device=device)
            if not isinstance(logpB, torch.Tensor):
                logpB = torch.tensor(float(logpB), device=device)

            refA = trainer._ref_logprob_trajectory(trajA) if getattr(trainer, "_ref_logprob_trajectory", None) else 0.0
            refB = trainer._ref_logprob_trajectory(trajB) if getattr(trainer, "_ref_logprob_trajectory", None) else 0.0
            if not isinstance(refA, torch.Tensor):
                refA = torch.tensor(float(refA), device=device)
            if not isinstance(refB, torch.Tensor):
                refB = torch.tensor(float(refB), device=device)

            z = self.beta * ((logpA - logpB) - (refA - refB))
            target = torch.tensor([winner], dtype=torch.float32, device=device)
            loss = F.binary_cross_entropy_with_logits(z, target)

            trainer.optimizer.zero_grad()
            loss.backward()
            trainer.optimizer.step()

            metrics = {"loss": float(loss.item()), "winner": winner}
            if self.eval_fn:
                metrics.update(self.eval_fn())
            return metrics

    def train(self, trainer, num_steps=1000, eval_interval=100):
        logs = []
        for s in range(1, num_steps + 1):
            m = self.step(trainer)
            if s % eval_interval == 0 or s == 1:
                print(f"[IPO] step {s} loss {m['loss']:.4f}")
                logs.append({"step": s, **m})
        return logs
