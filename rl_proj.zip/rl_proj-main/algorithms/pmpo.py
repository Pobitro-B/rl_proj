# algorithms/pmpo.py
"""
PMPO: Preference-based MPO (EM-style)
Provides:
- PMPO.step(trainer): perform one PMPO update using trainer (bandit or trajectory)
- PMPO.train(trainer, num_steps, eval_interval): convenience loop
"""

from typing import Optional
import numpy as np
import torch
import torch.nn.functional as F


class PMPO:
    def __init__(self, gamma: float = 4.0, lambda_div: float = 0.01, K: int = 8, device: Optional[str] = None, eval_fn=None):
        self.gamma = gamma
        self.lambda_div = lambda_div
        self.K = K
        self.device = device
        self.eval_fn = eval_fn

    def _compute_q(self, scores):
        scores = np.array(scores, dtype=float)
        logits = self.gamma * (scores - scores.max())
        ex = np.exp(logits)
        q = ex / (ex.sum() + 1e-12)
        return q

    def step(self, trainer):
        """
        Perform one PMPO update using the provided trainer.
        Returns a dict of metrics.
        """
        device = trainer.device if self.device is None else self.device

        # --- Bandit mode (candidate actions) ---
        if hasattr(trainer, "sample_candidates"):
            ctx = trainer.env.reset()
            candidates = trainer.sample_candidates(ctx, K=self.K)  # list of actions
            scores = trainer.score_actions(ctx, candidates)  # list/np of scores
            q = self._compute_q(scores)  # numpy array (K,)

            # tensors
            obs = torch.tensor(ctx, dtype=torch.float32, device=device).unsqueeze(0)
            obs_batch = obs.repeat(self.K, 1)
            acts_t = torch.tensor(np.array(candidates), dtype=torch.float32, device=device)

            obs_batch = obs_batch.to(device)
            acts_t = acts_t.to(device)

            # logprobs
            logp = trainer.policy.log_prob(obs_batch, acts_t).squeeze(-1)  # [K]
            if getattr(trainer, "ref_policy", None) is not None:
                with torch.no_grad():
                    logp_ref = trainer.ref_policy.log_prob(obs_batch, acts_t).squeeze(-1)
            else:
                logp_ref = torch.zeros_like(logp).detach()

            q_t = torch.tensor(q, dtype=torch.float32, device=device)
            expected_logp = (q_t * logp).sum()
            div = (q_t * (logp - logp_ref)).sum()
            loss = - expected_logp + self.lambda_div * div

            trainer.optimizer.zero_grad()
            loss.backward()
            trainer.optimizer.step()

            metrics = {
                "loss": float(loss.item()),
                "expected_logp": float(expected_logp.item()),
                "div": float(div.item()),
            }
            if self.eval_fn:
                metrics.update(self.eval_fn())

            return metrics

        # --- Trajectory mode (dmcontrol) ---
        else:
            trajs = [trainer.rollout() for _ in range(self.K)]
            scores = [trainer.trajectory_score(t) for t in trajs]
            q = self._compute_q(scores)

            loss = None
            expected_logp = 0.0
            div = 0.0
            for i, traj in enumerate(trajs):
                logp = trainer.logprob_trajectory(traj)
                # normalize to torch tensor on device
                if not isinstance(logp, torch.Tensor):
                    logp = torch.tensor(float(logp), dtype=torch.float32, device=device)
                if getattr(trainer, "_ref_logprob_trajectory", None):
                    ref_lp = trainer._ref_logprob_trajectory(traj)
                    if not isinstance(ref_lp, torch.Tensor):
                        ref_lp = torch.tensor(float(ref_lp), dtype=torch.float32, device=device)
                else:
                    ref_lp = torch.tensor(0.0, dtype=torch.float32, device=device)
                q_i = float(q[i])
                term = - q_i * logp + self.lambda_div * q_i * (logp - ref_lp)
                loss = term if loss is None else loss + term
                expected_logp += q_i * logp.item()
                div += q_i * (logp - ref_lp).item()

            trainer.optimizer.zero_grad()
            loss.backward()
            trainer.optimizer.step()

            metrics = {
                "loss": float(loss.item()),
                "expected_logp": float(expected_logp),
                "div": float(div),
            }
            if self.eval_fn:
                metrics.update(self.eval_fn())
            return metrics

    def train(self, trainer, num_steps: int = 1000, eval_interval: int = 100):
        logs = []
        for step in range(1, num_steps + 1):
            metrics = self.step(trainer)
            if step % eval_interval == 0 or step == 1:
                print(f"[PMPO] step {step} loss {metrics['loss']:.4f}")
                logs.append({"step": step, **metrics})
        return logs
